import discord
from discord.ext import commands, tasks
from discord import app_commands
import aiohttp
import asyncio
import json
import os
import re
from datetime import datetime, timezone
from bs4 import BeautifulSoup

# ─────────────────────────────────────────────
#  CONFIG  —  edit these before running
# ─────────────────────────────────────────────
BOT_TOKEN        = "YOUR_BOT_TOKEN_HERE"
UPDATE_CHANNEL_ID = 0          # channel ID to post auto-alerts
CHECK_INTERVAL_MINUTES = 15    # how often to poll for new updates

# ─────────────────────────────────────────────
#  PERSISTENT STATE FILE
# ─────────────────────────────────────────────
STATE_FILE = "last_seen.json"

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"client_version": None, "studio_version": None, "last_post_ids": []}

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

state = load_state()

# ─────────────────────────────────────────────
#  BOT SETUP
# ─────────────────────────────────────────────
intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

# ─────────────────────────────────────────────
#  ROBLOX API HELPERS
# ─────────────────────────────────────────────
ROBLOX_VERSION_URL   = "https://clientsettingscdn.roblox.com/v2/client-version/WindowsPlayer"
STUDIO_VERSION_URL   = "https://clientsettingscdn.roblox.com/v2/client-version/WindowsStudio"
DEPLOY_HISTORY_URL   = "https://setup.rbxcdn.com/DeployHistory.txt"
DEVFORUM_RSS_URL     = "https://devforum.roblox.com/c/updates/announcements/180.rss"
DEVFORUM_RELEASE_RSS = "https://devforum.roblox.com/c/updates/releases/180.rss"

async def fetch_json(session, url):
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as r:
            if r.status == 200:
                return await r.json()
    except Exception:
        pass
    return None

async def fetch_text(session, url):
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as r:
            if r.status == 200:
                return await r.text()
    except Exception:
        pass
    return None

async def get_client_version():
    async with aiohttp.ClientSession() as session:
        data = await fetch_json(session, ROBLOX_VERSION_URL)
        if data:
            return data.get("clientVersionUpload"), data.get("version")
    return None, None

async def get_studio_version():
    async with aiohttp.ClientSession() as session:
        data = await fetch_json(session, STUDIO_VERSION_URL)
        if data:
            return data.get("clientVersionUpload"), data.get("version")
    return None, None

async def get_devforum_posts(url, limit=5):
    """Parse RSS feed from DevForum and return recent post dicts."""
    async with aiohttp.ClientSession() as session:
        xml = await fetch_text(session, url)
    if not xml:
        return []
    soup = BeautifulSoup(xml, "xml")
    items = soup.find_all("item")[:limit]
    posts = []
    for item in items:
        posts.append({
            "title": item.title.text if item.title else "No title",
            "link":  item.link.text if item.link else "",
            "date":  item.pubDate.text if item.pubDate else "Unknown date",
            "desc":  BeautifulSoup(item.description.text, "html.parser").get_text()[:300] if item.description else "",
            "guid":  item.guid.text if item.guid else "",
        })
    return posts

async def get_deploy_history(lines=20):
    """Return last N lines of the CDN deploy history."""
    async with aiohttp.ClientSession() as session:
        text = await fetch_text(session, DEPLOY_HISTORY_URL)
    if not text:
        return []
    return [l.strip() for l in text.strip().splitlines()[-lines:] if l.strip()]

# ─────────────────────────────────────────────
#  EMBED BUILDERS
# ─────────────────────────────────────────────
def version_embed(title, upload, version, color):
    em = discord.Embed(title=title, color=color, timestamp=datetime.now(timezone.utc))
    em.add_field(name="Version String", value=f"`{version}`",       inline=True)
    em.add_field(name="Upload Hash",    value=f"`{upload}`",         inline=True)
    em.add_field(name="Checked At",     value=f"<t:{int(datetime.now().timestamp())}:F>", inline=False)
    em.set_footer(text="Roblox Update Tracker")
    return em

def post_embed(post, color=0x00b4d8):
    em = discord.Embed(
        title=post["title"][:256],
        url=post["link"],
        description=post["desc"] + ("…" if len(post["desc"]) == 300 else ""),
        color=color,
        timestamp=datetime.now(timezone.utc)
    )
    em.add_field(name="Published", value=post["date"], inline=False)
    em.set_footer(text="Roblox DevForum")
    return em

# ─────────────────────────────────────────────
#  BACKGROUND TASK — auto-post new updates
# ─────────────────────────────────────────────
@tasks.loop(minutes=CHECK_INTERVAL_MINUTES)
async def poll_updates():
    channel = bot.get_channel(UPDATE_CHANNEL_ID)
    if not channel:
        return

    # --- Client version check ---
    upload, version = await get_client_version()
    if upload and upload != state["client_version"]:
        state["client_version"] = upload
        save_state(state)
        em = version_embed("🎮 Roblox Client Updated!", upload, version, 0xff6b35)
        em.description = "A new Roblox **Player** version has been deployed to the CDN."
        await channel.send(embed=em)

    # --- Studio version check ---
    s_upload, s_version = await get_studio_version()
    if s_upload and s_upload != state["studio_version"]:
        state["studio_version"] = s_upload
        save_state(state)
        em = version_embed("🛠️ Roblox Studio Updated!", s_upload, s_version, 0x4cc9f0)
        em.description = "A new **Roblox Studio** version has been deployed to the CDN."
        await channel.send(embed=em)

    # --- DevForum announcement check ---
    posts = await get_devforum_posts(DEVFORUM_RSS_URL, limit=3)
    for post in posts:
        if post["guid"] not in state["last_post_ids"]:
            state["last_post_ids"].append(post["guid"])
            state["last_post_ids"] = state["last_post_ids"][-50:]  # keep last 50
            save_state(state)
            await channel.send(embed=post_embed(post, 0x9b5de5))

@poll_updates.before_loop
async def before_poll():
    await bot.wait_until_ready()

# ─────────────────────────────────────────────
#  SLASH COMMANDS
# ─────────────────────────────────────────────

@tree.command(name="roblox_version", description="Show the current live Roblox client version")
async def roblox_version(interaction: discord.Interaction):
    await interaction.response.defer()
    upload, version = await get_client_version()
    if not upload:
        await interaction.followup.send("❌ Could not reach Roblox version API.")
        return
    em = version_embed("🎮 Current Roblox Client Version", upload, version, 0xff6b35)
    await interaction.followup.send(embed=em)

@tree.command(name="studio_version", description="Show the current live Roblox Studio version")
async def studio_version(interaction: discord.Interaction):
    await interaction.response.defer()
    upload, version = await get_studio_version()
    if not upload:
        await interaction.followup.send("❌ Could not reach Roblox Studio version API.")
        return
    em = version_embed("🛠️ Current Roblox Studio Version", upload, version, 0x4cc9f0)
    await interaction.followup.send(embed=em)

@tree.command(name="latest_updates", description="Show the latest Roblox DevForum announcements")
async def latest_updates(interaction: discord.Interaction):
    await interaction.response.defer()
    posts = await get_devforum_posts(DEVFORUM_RSS_URL, limit=5)
    if not posts:
        await interaction.followup.send("❌ Could not fetch DevForum posts right now.")
        return
    await interaction.followup.send(f"**📢 Latest Roblox Announcements** ({len(posts)} found)")
    for post in posts:
        await interaction.followup.send(embed=post_embed(post, 0x9b5de5))

@tree.command(name="release_notes", description="Show latest Roblox release notes from DevForum")
async def release_notes(interaction: discord.Interaction):
    await interaction.response.defer()
    posts = await get_devforum_posts(DEVFORUM_RELEASE_RSS, limit=5)
    if not posts:
        await interaction.followup.send("❌ Could not fetch release notes right now.")
        return
    await interaction.followup.send(f"**📋 Latest Release Notes** ({len(posts)} found)")
    for post in posts:
        await interaction.followup.send(embed=post_embed(post, 0x06d6a0))

@tree.command(name="deploy_history", description="Show the last 15 CDN deploy entries")
async def deploy_history(interaction: discord.Interaction):
    await interaction.response.defer()
    lines = await get_deploy_history(15)
    if not lines:
        await interaction.followup.send("❌ Could not fetch deploy history.")
        return
    body = "\n".join(lines[-15:])
    em = discord.Embed(
        title="📦 Recent CDN Deploy History",
        description=f"```\n{body[:3900]}\n```",
        color=0xffd166,
        timestamp=datetime.now(timezone.utc)
    )
    em.set_footer(text="Source: setup.rbxcdn.com/DeployHistory.txt")
    await interaction.followup.send(embed=em)

@tree.command(name="upcoming_features", description="Show upcoming Roblox features announced on DevForum")
async def upcoming_features(interaction: discord.Interaction):
    await interaction.response.defer()
    # Pull the beta-announcements category RSS
    beta_rss = "https://devforum.roblox.com/c/updates/announcements/180.rss"
    posts = await get_devforum_posts(beta_rss, limit=8)
    # Filter for posts that mention beta, upcoming, preview, or feature flag keywords
    keywords = ["beta", "upcoming", "preview", "coming soon", "feature flag", "early access", "roadmap"]
    filtered = [p for p in posts if any(kw in p["title"].lower() or kw in p["desc"].lower() for kw in keywords)]
    if not filtered:
        filtered = posts[:3]  # fallback: just show latest
        note = "*(No posts explicitly mentioning upcoming features found — showing latest announcements instead.)*"
    else:
        note = f"*Filtered {len(filtered)} post(s) mentioning beta/upcoming/preview features.*"
    await interaction.followup.send(f"**🔭 Upcoming / Beta Features**\n{note}")
    for post in filtered[:5]:
        await interaction.followup.send(embed=post_embed(post, 0xf72585))

@tree.command(name="set_update_channel", description="Set this channel for auto update alerts (Admin only)")
@app_commands.checks.has_permissions(administrator=True)
async def set_update_channel(interaction: discord.Interaction):
    global UPDATE_CHANNEL_ID
    UPDATE_CHANNEL_ID = interaction.channel_id
    await interaction.response.send_message(
        f"✅ Update alerts will now be posted in <#{interaction.channel_id}>.\n"
        f"The bot checks every **{CHECK_INTERVAL_MINUTES} minutes**."
    )

@tree.command(name="help_roblox", description="Show all Roblox tracker commands")
async def help_roblox(interaction: discord.Interaction):
    em = discord.Embed(title="🤖 Roblox Update Bot — Commands", color=0x00b4d8)
    commands_list = [
        ("/roblox_version",       "Current live Roblox client version"),
        ("/studio_version",       "Current live Roblox Studio version"),
        ("/latest_updates",       "Latest DevForum announcements"),
        ("/release_notes",        "Latest official release notes"),
        ("/upcoming_features",    "Upcoming / beta features from DevForum"),
        ("/deploy_history",       "Last 15 CDN deploy log entries"),
        ("/set_update_channel",   "Set auto-alert channel (Admin only)"),
    ]
    for cmd, desc in commands_list:
        em.add_field(name=cmd, value=desc, inline=False)
    em.add_field(
        name="ℹ️ About auto-alerts",
        value=f"The bot polls Roblox every **{CHECK_INTERVAL_MINUTES} min** and posts to the configured channel when:\n"
              "• Client version changes\n• Studio version changes\n• New DevForum announcement appears",
        inline=False
    )
    em.set_footer(text="Roblox Update Tracker Bot")
    await interaction.response.send_message(embed=em)

# ─────────────────────────────────────────────
#  ON READY
# ─────────────────────────────────────────────
@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user} ({bot.user.id})")
    await tree.sync()
    print("✅ Slash commands synced.")
    poll_updates.start()
    print(f"✅ Polling for updates every {CHECK_INTERVAL_MINUTES} minutes.")

bot.run(BOT_TOKEN)
