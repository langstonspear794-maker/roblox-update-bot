# Roblox Update Tracker Bot — Setup Guide

## What it does
- ✅ Detects new **Roblox client** version deployments (live, real-time)
- ✅ Detects new **Roblox Studio** version deployments
- ✅ Posts **DevForum announcements** as they appear
- ✅ Shows **release notes** and **beta/upcoming features**
- ✅ Shows the raw **CDN deploy history** log
- ✅ **Auto-alerts** a channel whenever something new is detected

---

## Setup Steps

### 1. Create a Discord Bot
1. Go to https://discord.com/developers/applications
2. Click **New Application**, give it a name
3. Go to **Bot** → **Add Bot**
4. Under **Privileged Gateway Intents**, enable **Message Content Intent**
5. Copy your **Bot Token**

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure `bot.py`
Open `bot.py` and edit the top section:
```python
BOT_TOKEN         = "paste your token here"
UPDATE_CHANNEL_ID = 0   # set this via /set_update_channel or paste the channel ID
CHECK_INTERVAL_MINUTES = 15  # how often to check (minimum recommended: 10)
```

### 4. Invite the bot to your server
In the Developer Portal:
- Go to **OAuth2 → URL Generator**
- Scopes: `bot`, `applications.commands`
- Permissions: `Send Messages`, `Embed Links`, `Read Message History`
- Open the generated URL and invite the bot

### 5. Run the bot
```bash
python bot.py
```

---

## Commands

| Command | Description |
|---|---|
| `/roblox_version` | Current live Roblox client version |
| `/studio_version` | Current live Roblox Studio version |
| `/latest_updates` | Latest DevForum announcements |
| `/release_notes` | Official Roblox release notes |
| `/upcoming_features` | Beta / upcoming feature posts |
| `/deploy_history` | Last 15 CDN deploy log entries |
| `/set_update_channel` | Set this channel for auto-alerts (Admin) |
| `/help_roblox` | Show all commands |

---

## About "Future Updates / Downloads"

### What's possible ✅
- The bot reads the **CDN deploy history** at `setup.rbxcdn.com/DeployHistory.txt`
  which sometimes contains staged/canary builds before they go fully live.
- It filters DevForum for posts tagged **beta**, **upcoming**, **preview**, and **early access**.
- It can detect a new version hash *before* the auto-updater pushes it to your PC.

### What's NOT possible ❌
- Roblox does **not** publish a public roadmap with exact dates.
- Downloading future/unreleased builds directly is **against Roblox's Terms of Service**
  and would require bypassing their CDN authentication — this bot does not do that.
- The `/upcoming_features` command is the best approximation: it shows officially announced
  features that are in beta or coming soon, sourced directly from Roblox staff posts.

---

## Keeping it running 24/7

Use a free hosting service:
- **Railway** (https://railway.app) — easiest, free tier available
- **Render** (https://render.com) — free background worker
- **Replit** — free but sleeps; pair with UptimeRobot to keep awake
- **Your own VPS/server** — run with `screen` or `pm2`

---

## Troubleshooting

- **Commands not showing?** Wait 1–2 minutes after startup for Discord to register slash commands globally. Or re-run the bot.
- **No alerts?** Make sure `UPDATE_CHANNEL_ID` is set (run `/set_update_channel` in your server).
- **Rate limited?** Increase `CHECK_INTERVAL_MINUTES` to 30.
